##2.	Create a program that takes user input for a temperature in Celsius and converts it to Fahrenheit.
def celsius_to_fahrenheit(celsius):
    return ( celsius*9/5)+32
celsius=float(input("enter temp in c :"))
fahrenheit=celsius_to_fahrenheit(celsius)
print(f"{celsius} dgree celsiud is equal to {fahrenheit} degree fahrenhe:56")