##1.	Write a Python program to calculate the area of a circle given its radius
r=float(input("enter any number r:"))
pi=3.14
area_of_circle= print(pi*r*r)