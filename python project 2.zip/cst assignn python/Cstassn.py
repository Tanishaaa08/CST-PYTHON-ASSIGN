area = 3.14* radius*radius 
print(f"The area od the circle is: {area}")#output 